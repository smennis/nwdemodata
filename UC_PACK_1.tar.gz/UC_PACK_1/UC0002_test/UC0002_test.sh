#!/bin/bash
NwLogPlayer -f logs/test.log -s $LOG_DECODER_IP
echo "UC0002 complete."
